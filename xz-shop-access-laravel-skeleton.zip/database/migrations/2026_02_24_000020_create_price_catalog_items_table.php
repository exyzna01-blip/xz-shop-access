<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('price_catalog_items', function (Blueprint $table) {
            $table->id();
            $table->string('service');
            $table->string('duration')->nullable();
            $table->string('category');
            $table->string('devices')->default('');
            $table->decimal('price', 10, 2)->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->index(['service','duration','category','devices']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('price_catalog_items');
    }
};
